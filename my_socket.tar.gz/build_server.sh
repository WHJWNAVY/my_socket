#########################################################################
# File Name: build_server.sh
# Author: wnavy
# mail: whjwnavy@163.com
# Created Time: Fri 01 Sep 2017 03:33:59 PM CST
#########################################################################
#!/bin/bash
gcc test_server.c my_socket.c -o test_server
