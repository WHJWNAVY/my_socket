#########################################################################
# File Name: build_client.sh
# Author: wnavy
# mail: whjwnavy@163.com
# Created Time: Fri 01 Sep 2017 03:35:43 PM CST
#########################################################################
#!/bin/bash
gcc test_client.c my_socket.c -o test_client
